<?php

$Dbhost="localhost";
$DbUsername="root";
$DbPassword="root";
$Dbname="borrowingandinventorysystemdb";
$DbConnect=new mysqli ($Dbhost, $DbUsername, $DbPassword, $Dbname);
?>