<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
			<link rel="stylesheet" type="text/css" href="../plugins/sweetalert.css">
		<script type="text/javascript" src="../plugins/sweetalert-dev.js"></script>
	<body>
	</body>
</html>
<?php
	session_start();
	require_once 'connect.php';

	$username=$_POST['username'];
	$u_password=md5($_POST['u_password']);

	if (empty($username) || empty($u_password))
	{
		header ('location:../loginpage/login_form_stud_fac.php');
	}
	else
	{
		$sql="SELECT user_id, user_type FROM tbl_user  WHERE username=? AND u_password=?";
		$qry=$DbConnect->prepare($sql);
		$qry->bind_param("ss",$username,$u_password);
		$qry->bind_result($user_id,$user_type);
		$qry->execute();
		$count=0;

		while ($qry->fetch()) 
		{
			$count++;
			$_SESSION['user_id'] = $user_id;
			$_SESSION['user_type'] = $user_type;
		}

		if ($count==1)
		{
			if ($user_type == "Student")
			{
			header ('location:../users/student/dashboard.php');
			}
			else if ($user_type == "Faculty")
			{
			header ('location:../users/faculty/dashboard.php');
			}
			else
			{
				error1();
			}
		}
		else
		{
			error1();
		}
	}

	function error1()
		{
			echo '<script>
			swal({
				title: "Incorrect Username, Password",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "../loginpage/login_form_stud_fac.php";
			});
			</script>';
		}
			function err()
		{
			echo '<script>
			swal({
				title: "This Account is Inactive",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "../loginpage/login_form_stud_fac.php";
			});
			</script>';
		}
?>