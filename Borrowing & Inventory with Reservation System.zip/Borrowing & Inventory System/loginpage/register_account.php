  <!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../dist/sweetalert.css">
    <script type="text/javascript" src="../dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

   
  <?php  
 $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
 if(isset($_POST["avatar"]))  
 {    $f_name = $_POST['f_name'];
      $l_name = $_POST['l_name'];
      $m_name = $_POST['m_name'];
      $email = $_POST['email'];  
      $contact = $_POST['contact'];  
      $username = $_POST['username'];  
      $user_type = $_POST['user_type'];
      $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
      $u_password = $_POST['u_password']; 
      $passwordmd5 = md5($u_password); 
      
     
            $query = "INSERT INTO tbl_user(f_name,l_name,m_name,email,contact,username,u_password,user_type,avatar) VALUES ('$f_name','$l_name','$m_name','$email','$contact','$username','$passwordmd5','$user_type','$avatar')";  
      if(mysqli_query($connect, $query))  
      {  
       succ();
     }
    }
    else
  {
  error2();
}
  function succ()
    {
      echo '<script>
      swal({
        title: "Registered Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "registrationform.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "registrationform.php ";
      });
      </script>';
    }  
 ?>  
