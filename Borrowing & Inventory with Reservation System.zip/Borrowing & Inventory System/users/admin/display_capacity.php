
<?php
  require_once("../../connection/connect.php");
  $user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_brand.brand_id,tbl_brand.brand_name,tbl_brand.description,tbl_user.user_id,tbl_user.f_name,tbl_user.l_name,tbl_user.m_name FROM tbl_brand INNER JOIN tbl_user ON tbl_brand.user_id=tbl_user.user_id GROUP BY tbl_brand.brand_name ASC";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($brand_id,$brand_name,$description,$user_id,$f_name,$l_name,$m_name);
  $qry->execute();

  while ($qry->fetch())
  {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,f_name,l_name,m_name FROM tbl_user WHERE user_id=?";
      ?>

      <tr>
      
        <td><b style="color: darkblue;"><?php echo $brand_name; ?></b> </td>  
        <td><?php echo $description; ?> </td>
        <td><?php echo $f_name; ?> <?php echo $l_name; ?></td>
         <td>
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php echo $brand_id; ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#deleteapp<?php echo $brand_id; ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                  <div class="modal fade" id="update<?php echo $brand_id;?>">
                        <div class="modal-dialog modal-sm">
                            <form action="update_capacity.php" method="post" id="form1<?php echo $brand_id; ?>"  name="form1">
                         <input type="hidden" name="brand_idz" value="<?php echo $brand_id; ?>">
                         <input type="hidden" name="brand_namez" value="<?php echo $brand_name; ?>">
                         <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Brand</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Brand</label>
                                  <input type="text"  class="form-control" value="<?php echo $brand_name; ?>" name="brand_name">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputPassword1">Description</label>
                                  <textarea  rows="4" class="form-control" name="description"><?php echo htmlspecialchars($description);?></textarea>
                                </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php echo $brand_id; ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="deleteapp<?php echo $brand_id;?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_capacity.php? brand_id=<?php echo $brand_id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         

        
          
<?php 
  }   
  
?>
