<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
		<script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("../../connection/connect.php");
	 $f_name = $_POST['f_name'];
	if (!empty($f_name))
		{
			  $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
			  $f_name = $_POST['f_name'];
		      $l_name = $_POST['l_name'];
		      $m_name = $_POST['m_name'];
		      $email = $_POST['email'];  
		      $contact = $_POST['contact'];  
		      $username = $_POST['username'];  
		      $user_type = "Admin";
		      $u_password = $_POST['u_password'];
     			 $passwordmd5 = md5($u_password); 
		      $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
			$sql="INSERT INTO tbl_user (f_name,l_name,m_name,email,contact,username,u_password,user_type,avatar) VALUES ('$f_name','$l_name','$m_name','$email','$contact','$username','$passwordmd5','$user_type','$avatar')";  
      if(mysqli_query($connect, $sql))  
			{
				 succ();

			}
			else
		{
			error1();
		}
		}
		else
		{
			error1();
		}

		function succ()
		{
			echo '<script>
			swal({
				title: "Added Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "user.php ";
			});
			</script>';
		}
		function error1()
		{
			echo '<script>
			swal({
				title: "Error!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "user.php ";
			});
			</script>';
		}
	
?>