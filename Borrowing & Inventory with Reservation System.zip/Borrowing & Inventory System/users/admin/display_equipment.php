<?php  
include '../../connection/connect.php';
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_equipment.equipment_id, tbl_equipment.equipment_name,  tbl_equipment.quantity, tbl_equipment.code,tbl_equipment.avatar,tbl_equipment.date_added, tbl_equipment.eq_description, tbl_brand.brand_id,tbl_brand.brand_name,tbl_unit.unit_id,tbl_unit.unit_name,tbl_supplier.supplier_id,tbl_supplier.supplier_name,tbl_supplier.description, tbl_user.user_id,tbl_user.f_name,tbl_user.l_name
FROM tbl_equipment INNER JOIN tbl_brand ON tbl_equipment.brand_id = tbl_brand.brand_id INNER JOIN tbl_unit ON tbl_equipment.unit_id = tbl_unit.unit_id INNER JOIN tbl_supplier ON tbl_equipment.supplier_id = tbl_supplier.supplier_id INNER JOIN tbl_user ON tbl_equipment.user_id = tbl_user.user_id
GROUP BY tbl_equipment.equipment_id, tbl_equipment.equipment_name, tbl_equipment.quantity, tbl_equipment.code, tbl_brand.brand_id,tbl_brand.brand_name,tbl_unit.unit_id,tbl_unit.unit_name,tbl_supplier.supplier_id,tbl_supplier.supplier_name,tbl_user.user_id,tbl_user.f_name,tbl_user.l_name ASC";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($equipment_id,$equipment_name,$quantity,$code,$avatar,$date_added,$eq_description,$brand_id,$brand_name,$unit_id,$unit_name,$supplier_id,$supplier_name,$description,$user_id,$f_name,$l_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  

while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,f_name,l_name FROM tbl_user WHERE user_id=?";
    ?>
      <tr>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
         <td><?php printf ("%s", $row["equipment_name"]); ?> </td>
         <td><?php printf ("%s", $row["code"]); ?> </td>
         <td><?php printf ("%s", $row["brand_name"]); ?> </td>
          <td><?php printf ("%s", $row["quantity"]); ?> </td>
         <td><?php printf ("%s", $row["unit_name"]); ?> </td>
         <td><?php printf ("%s", $row["date_added"]); ?> </td>
         <td><?php printf ("%s", $row["supplier_name"]); ?> </td>
         <td><?php printf ("%s", $row["eq_description"]); ?> </td>
         <td><?php printf ("%s", $row["f_name"]); ?> <?php printf ("%s", $row["l_name"]); ?> </td>
         <td>
          <button type='button' class='btn btn-xs btn-primary ' data-toggle='modal' data-target='#view<?php printf ("%s", $row["equipment_id"]); ?>'><i class="fa fa-image "></i>  </button>
              <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["equipment_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
              
          <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php printf ("%s", $row["equipment_id"]); ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
        
                      <div class="modal fade" id="delete<?php printf ("%s", $row["equipment_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_equipment.php? equipment_id=<?php printf ("%s", $row["equipment_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
     <div class="modal fade" id="update<?php printf ("%s", $row["equipment_id"]); ?>">
                        <div class="modal-dialog modal-md">
                           <form action="update_equipment.php"  method="post" id="form1<?php printf ("%s", $row["equipment_id"]); ?>" enctype="multipart/form-data" name="form1" >
                       <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <input type="hidden" name="equipment_idz" value="<?php printf ("%s", $row["equipment_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Item</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-9">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Item</label>
                                  <input type="text" class="form-control" id="" name="equipment_name"  value="<?php printf ("%s", $row["equipment_name"]); ?>">
                                </div>
                              </div>
                                <div class="col-3">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Quantity</label>
                                  <input type="number" class="form-control" id="" min="0" name="quantity"  value="<?php printf ("%s", $row["quantity"]); ?>">
                                </div>
                              </div>
                             
                              <div class="col-6">
                                  <div class="form-group">
                                  <label>Code</label>
                                   <input type="text" class="form-control" id="" name="code"  value="<?php printf ("%s", $row["code"]); ?>">
                                </div>
                              </div>
                              <div class="col-6">
                                  <div class="form-group">
                                  <label>Brand</label>
                                  <select class="form-control select2" name="brand_id">
                                    <option selected="" value=<?php printf ("%s", $row["brand_id"]); ?>><?php printf ("%s", $row["brand_name"]); ?></option>
                                     <?php
                                    include '../../connection/connect.php';
                                    $sql="SELECT tbl_brand.brand_id,tbl_brand.brand_name FROM tbl_brand ORDER BY tbl_brand.brand_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($brand_id,$brand_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $brand_id ?>"><?php echo $brand_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-6">
                                  <div class="form-group">
                                  <label>Status</label>
                                  <select class="form-control select2" name="unit_id">
                                    <option selected="" value=<?php printf ("%s", $row["unit_id"]); ?>><?php printf ("%s", $row["unit_name"]); ?></option>
                                    <?php
                                     include '../../connection/connect.php';
                                    $sql="SELECT tbl_unit.unit_id,tbl_unit.unit_name FROM tbl_unit ORDER BY tbl_unit.unit_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($unit_id,$unit_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $unit_id ?>"><?php echo $unit_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                               <div class="col-6">
                                  <div class="form-group">
                                  <label>Note</label>
                                  <select class="form-control select2" name="supplier_id">
                                    <option selected="" value=<?php printf ("%s", $row["supplier_id"]); ?>><?php printf ("%s", $row["supplier_name"]); ?></option>
                                    <?php
                                    require_once("../../connection/connect.php");
                                    $sql="SELECT tbl_supplier.supplier_id,tbl_supplier.supplier_name FROM tbl_supplier ORDER BY tbl_supplier.supplier_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($supplier_id,$supplier_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $supplier_id ?>"><?php echo $supplier_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                              </div>
                              <div class="col-12">
                               <div class="form-group">
                                  <label for="exampleInputPassword1">Description</label>
                                  <textarea  rows="4" class="form-control" name="eq_description"><?php printf ("%s", $row["eq_description"]); ?></textarea>
                                </div>
                              </div>
                              <div class="col-6">

                              </div>
                               <div class="col-6">
                              <div class="custom-file">
                                <input type="file" class="custom-file-input" name="avatar" id="avatar">
                                  <label class="custom-file-label" for="customFile" style="font-size:14px">Choose Image</label>
                              </div>
                              </div>
                              </div>
                            </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                            <input type="submit" name="avatar" id="avatar"  value="Update" class="btn btn-primary"  /> 
                           </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="view<?php echo $row['equipment_id']; ?>">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title"></h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="col-12 col-sm-12 col-md-12 d-flex align-items-stretch flex-column">
                            <div class="card bg-light d-flex flex-fill">
                              <div class="card-header text-muted border-bottom-0">
                                Equipment Detail
                              </div>
                              <div class="card-body pt-0">
                                <div class="row">
                                  <div class="col-7">
                                    <h2 class="lead"><b><?php printf ("%s", $row["equipment_name"]); ?></b></h2>
                                    <p class="text-muted text-sm"><b>About: </b> <?php printf ("%s", $row["code"]); ?>/ <?php printf ("%s", $row["brand_name"]); ?> / <?php printf ("%s", $row["unit_name"]); ?> / Qty:  <?php printf ("%s", $row["quantity"]); ?> </p>
                                    <ul class="ml-4 mb-0 fa-ul text-muted">
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-edit"></i> </span> Note: <?php printf ("%s", $row["supplier_name"]); ?></li>
                                    </ul>
                                  </div>
                                  <div class="col-5 text-center">
                                    <?php
                                          echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'"  alt="user-avatar" class="img-square img-fluid" /> '; 
                                          ?>
                                  </div>
                                </div>
                              </div>
                              
                            </div>
                          </div>
                          </div>
                          </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
          

<?php 
  }   
  
?>
