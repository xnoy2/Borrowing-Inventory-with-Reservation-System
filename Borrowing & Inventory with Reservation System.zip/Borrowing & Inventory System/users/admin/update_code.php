
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once '../../connection/connect.php';
$code_id= isset($_POST['code_idz'])? $_POST['code_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$code_name=$_POST['code_name'];
$description=$_POST['description'];
    $sql = "UPDATE tbl_equipment_code SET code_name=?, description=?, user_id=? WHERE code_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssss",$code_name,$description,$user_id,$code_id);
    if ($qry->execute())
    {
     succ();    
    }
    else
    {
        err();
    }

function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "equipment_code.php";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "equipment_code.php";
            });
            </script>';
        }

?>