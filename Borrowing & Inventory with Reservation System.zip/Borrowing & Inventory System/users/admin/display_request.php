<?php  
include '../../connection/connect.php';
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_request.request_id,tbl_request.req_quantity,tbl_request.date_requested,tbl_request.status,tbl_equipment.equipment_id,tbl_equipment.equipment_name,tbl_equipment.code,tbl_equipment.avatar,tbl_user.user_id, tbl_user.f_name,tbl_user.l_name,tbl_user.user_type FROM tbl_request INNER JOIN tbl_equipment ON tbl_request.equipment_id = tbl_equipment.equipment_id INNER JOIN tbl_user ON tbl_request.user_id = tbl_user.user_id
WHERE tbl_request.status = 3 GROUP BY tbl_request.request_id,tbl_request.req_quantity,tbl_request.date_requested,tbl_equipment.equipment_id,tbl_equipment.equipment_name,tbl_equipment.code,tbl_equipment.avatar,tbl_user.user_id, tbl_user.f_name,tbl_user.l_name,tbl_user.user_type ASC";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($request_id,$req_quantity,$date_requested,$status,$equipment_id,$equipment_name,$code,$avatar,$user_id,$f_name,$l_name,$user_type);
$qry->execute();
$result = mysqli_query($connect, $sql);  

while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,f_name,l_name FROM tbl_user WHERE user_id=?";
    ?>
      <tr>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
         <td><?php printf ("%s", $row["equipment_name"]); ?> </td>
         <td><?php printf ("%s", $row["code"]); ?> </td>
         <td><?php printf ("%s", $row["req_quantity"]); ?> </td>
          <td><?php printf ("%s", $row["date_requested"]); ?> </td>

         <td>
          <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#view<?php printf ("%s", $row["request_id"]); ?>'><i class='fa fa-edit'></i> 
         </button>
        </td>
              
      </tr>
        
                      <div class="modal fade" id="delete<?php printf ("%s", $row["request_id"]); ?>" style="margin-left: 30%; margin-top: 20%">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you to want cancel your request?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_request.php? request_id=<?php printf ("%s", $row["request_id"]); ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
    
                      <div class="modal fade" id="view<?php echo $row['request_id']; ?>">
                        <div class="modal-dialog modal-md">
                          <form action="approved_request.php" method="post" id="form1<?php printf ("%s", $row["request_id"]); ?>"  name="form1">
                          <input type="hidden" name="equipment_idz" value="<?php printf ("%s", $row["equipment_id"]); ?>">
                          <input type="hidden" name="request_idz" value="<?php printf ("%s", $row["request_id"]); ?>">
                          <input type="hidden" name="user_idz" value="<?php printf ("%s", $row["user_id"]); ?>">
                          <input type="hidden" name="req_quantityz" value="<?php printf ("%s", $row["req_quantity"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title"></h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                            <div class="card bg-light d-flex flex-fill">
                              <div class="card-header text-muted border-bottom-0">
                                Requestor Detail
                              </div>
                              <div class="card-body pt-0">
                                <div class="row">
                                  <div class="col-7">
                                    <h2 class="lead"><b><?php printf ("%s", $row["user_type"]); ?></b></h2>
                                    <p class="text-muted text-sm"><b>Requestor: </b> <?php printf ("%s", $row["f_name"]); ?> <?php printf ("%s", $row["l_name"]); ?> </p>
                                    <ul class="ml-4 mb-0 fa-ul text-muted">
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-balance-scale"></i> </span> Request Quantity: <?php printf ("%s", $row["req_quantity"]); ?></li>
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-calendar-alt"></i> </span> Date Requested: <?php printf ("%s", $row["date_requested"]); ?></li>

                                    </ul>
                                    <div class="b" style="margin-left:10%; margin-top:48px;">
                                   </div>
                                  </div>
                                  <div class="col-5 text-center">
                                     Equipment: <b><?php printf ("%s", $row["equipment_name"]); ?></b>
                                    <?php
                                          echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'"  alt="user-avatar" class="img-square img-fluid" /> '; 
                                          ?>
                                  </div>
                                </div>
                              </div>
                              
                            </div>
                          </div>
                          <div class="modal-footer justify-content-between">
                             <a href="rejected_request.php? request_id=<?php printf ("%s", $row["request_id"]); ?>" style="margin-left:10px"> <button type="button"  class="btn btn-danger btn-xs" ><i class="fa fa-times"></i> Reject</button></a>
                              <button type="submit"  onclick="form1<?php printf ("%s", $row["request_id"]); ?>.submit();" form="form1" class="btn btn-primary btn-xs" style="margin-right:324px"><i class="fa fa-check"></i> Approved</button>
                            </div>
                          </div>
                          </div>
                          <!-- /.modal-content -->
                        </form>
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      

          
<?php 
  }   
  
?>
