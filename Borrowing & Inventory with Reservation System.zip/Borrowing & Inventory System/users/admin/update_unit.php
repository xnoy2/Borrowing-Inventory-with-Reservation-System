
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once '../../connection/connect.php';
$unit_id= isset($_POST['unit_idz'])? $_POST['unit_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$unit_name=$_POST['unit_name'];
$description=$_POST['description'];
    $sql = "UPDATE tbl_unit SET unit_name=?, description=?, user_id=? WHERE unit_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssss",$unit_name,$description,$user_id,$unit_id);
    if ($qry->execute())
    {
     succ();    
    }
    else
    {
        err();
    }
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "unit.php";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "unit.php";
            });
            </script>';
        }
     
?>