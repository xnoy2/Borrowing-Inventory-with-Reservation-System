<?php  
require_once ("../../connection/connect.php");
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_user.user_id,tbl_user.f_name,tbl_user.l_name,tbl_user.m_name,tbl_user.email,tbl_user.contact,tbl_user.username,tbl_user.u_password,tbl_user.user_type,tbl_user.avatar
FROM tbl_user
GROUP BY tbl_user.user_id,tbl_user.f_name,tbl_user.m_name,tbl_user.l_name,tbl_user.email,tbl_user.contact,tbl_user.username,tbl_user.u_password,tbl_user.user_type,tbl_user.avatar ASC";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($user_id,$f_name,$l_name,$m_name,$email,$contact,$username,$u_password,$user_type,$avatar);
$qry->execute();
$result = mysqli_query($connect, $sql);  

while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,f_name,l_name FROM tbl_user WHERE user_id=?";
    ?>
      <tr>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
         <td><?php printf ("%s", $row["f_name"]); ?> <?php printf ("%s", $row["m_name"]); ?>  <?php printf ("%s", $row["l_name"]); ?> </td>
         <td><?php printf ("%s", $row["email"]); ?> </td>
         <td><?php printf ("%s", $row["contact"]); ?> </td>
         <td><?php printf ("%s", $row["username"]); ?> </td>
         <td><?php printf ("%s", $row["user_type"]); ?> </td>
         <td>
          <button type='button' class='btn btn-xs btn-primary ' data-toggle='modal' data-target='#view<?php printf ("%s", $row["user_id"]); ?>'><i class="fa fa-image "></i>  </button>
              <button type='button' class='btn btn-warning btn-xs' data-toggle='modal' data-target='#password<?php printf ("%s", $row["user_id"]); ?>'><i class='fa fa-unlock'></i> 
              </button> 
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php printf ("%s", $row["user_id"]); ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
        </td>
              
      </tr>
     <div class="modal fade" id="update<?php printf ("%s", $row["user_id"]); ?>">
                        <div class="modal-dialog modal-md">
                            <form action="update_user.php"  method="post" id="form1<?php printf ("%s", $row["user_id"]); ?>" enctype="multipart/form-data" name="form1" >
                         <input type="hidden" name="user_idz" value="<?php printf ("%s", $row["user_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update User</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">First Name</label>
                                  <input type="text" class="form-control" id="" name="f_name" value="<?php printf ("%s", $row["f_name"]); ?>" >
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Middle Name</label>
                                  <input type="text" class="form-control" id="" name="m_name" value="<?php printf ("%s", $row["m_name"]); ?>" >
                                </div>
                              </div>
                              <div class="col-4">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Last Name</label>
                                  <input type="text" class="form-control" id="" name="l_name" value="<?php printf ("%s", $row["l_name"]); ?>" >
                                </div>
                              </div>
                                <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Username</label>
                                  <input type="text" class="form-control" name="username" value="<?php printf ("%s", $row["username"]); ?>" >
                                </div>
                              </div>
                              <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Email</label>
                                  <input type="text" class="form-control"  name="email" value="<?php printf ("%s", $row["email"]); ?>" >
                                </div>
                              </div>
                               <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Contact</label>
                                  <input type="text" class="form-control"  name="contact" value="<?php printf ("%s", $row["contact"]); ?>" >
                                </div>
                              </div>
                               <div class="col-6">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">User Type</label>
                                  <?php if ($row['user_type'] == "Admin")
                                  {
                                    ?>
                                     <select class="form-control"  name="user_type">
                                      <option selected="">Admin</option>
                                      </select>
                                 <?php
                               }

                                  else
                                  {
                                    ?>
                                    <select class="form-control"  name="user_type">
                                   <?php
                                   if ($row['user_type'] == "Student")
                                   {
                                     ?>
                                   <option selected="">Student</option>
                                   <option>Faculty</option>
                                   <?php
                               }
                               else
                               {
                                ?>
                                   <option selected="">Faculty</option>
                                   <option>Student</option>
                               <?php
                           }
                           ?>
                                </select>
                                 <?php
                                  }
                                  ?>
                                </div>
                              </div>
                              
                              <div class="col-6">
                                <div class="form-group">
                                  <div class="custom-file">
                                <input type="file" class="custom-file-input" name="avatar" id="avatar">
                                  <label class="custom-file-label" for="customFile" style="font-size:14px">Choose New Avatar</label>
                              </div>
                                </div>
                              </div>
                              </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <input type="submit" name="avatar" id="avatar" value="Submit" class="btn btn-primary" /> 
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="view<?php echo $row['user_id']; ?>">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title"></h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="col-12 col-sm-12 col-md-12 d-flex align-items-stretch flex-column">
                            <div class="card bg-light d-flex flex-fill">
                              <div class="card-header text-muted border-bottom-0">
                                User Detail
                              </div>
                              <div class="card-body pt-0">
                                <div class="row">
                                  <div class="col-7">
                                    <h2 class="lead"><b><?php printf ("%s", $row["f_name"]); ?> <?php printf ("%s", $row["m_name"]); ?> <?php printf ("%s", $row["l_name"]); ?></b></h2>
                                    <p class="text-muted text-sm"><b>About: </b> User Type :<?php printf ("%s", $row["user_type"]); ?>/Username : <?php printf ("%s", $row["username"]); ?> </p>
                                    <ul class="ml-4 mb-0 fa-ul text-muted">
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-envelope"></i> </span> Email: <?php printf ("%s", $row["email"]); ?></li>
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-phone"></i> </span> Contact: <?php printf ("%s", $row["contact"]); ?></li>
                                    </ul>
                                  </div>
                                  <div class="col-5 text-center">
                                    <?php
                                          echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'"  alt="user-avatar" class="img-circle img-fluid" /> '; 
                                          ?>
                                  </div>
                                </div>
                              </div>
                              
                            </div>
                          </div>
                          </div>
                          </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="password<?php printf ("%s", $row["user_id"]); ?>">
        <div class="modal-dialog modal-sm">
                            <form action="update_password.php"  method="post" id="form1<?php printf ("%s", $row["user_id"]); ?>" enctype="multipart/form-data" name="form1" >
                         <input type="hidden" name="user_idz" value="<?php printf ("%s", $row["user_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Change Password</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Old Password</label>
                                  <input type="password" class="form-control" id="" disabled="" name="full_name" value="**********" >
                                </div>
                              </div>
                                 <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">New Password</label>
                                  <input type="password" required="" class="form-control" id="" name="npassword" placeholder="Enter New Password .. ">
                                </div>
                              </div>
                                 <div class="col-12">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Confirm Password</label>
                                 <input type="password" required="" class="form-control" id="" name="cpassword" placeholder="Confirm Password .. ">
                                </div>
                              </div>
                              </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <input type="submit" name="avatar" id="avatar" value="Submit" class="btn btn-primary" /> 
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
        <!-- /.modal-dialog -->
      </div>
<?php 
  }   
  
?>
