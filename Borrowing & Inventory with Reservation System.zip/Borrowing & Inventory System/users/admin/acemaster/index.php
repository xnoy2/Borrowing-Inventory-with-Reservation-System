<?php
	session_start();
	if($_SESSION['role'] == "Admin") {
		
		header("location:../admin/home.php");
	}
	else if($_SESSION['role'] == "User") {
		
		header("location:../coordinator/dashboard.php");
	}
	else {
		
		header("location:../index.php");
	}
?>