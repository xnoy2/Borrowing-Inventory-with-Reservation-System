
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once '../../connection/connect.php';
$brand_id= isset($_POST['brand_idz'])? $_POST['brand_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$brand_name=$_POST['brand_name'];
$description=$_POST['description'];
    $sql = "UPDATE tbl_brand SET brand_name=?, description=?, user_id=? WHERE brand_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssss",$brand_name,$description,$user_id,$brand_id);
    if ($qry->execute())
    {
     succ();    
    }
    else
    {
        err();
    }
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "capacity.php";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "capacity.php";
            });
            </script>';
        }
     
?>