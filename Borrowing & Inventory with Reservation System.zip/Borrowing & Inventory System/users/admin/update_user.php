
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body> 
</html>
<?php
include '../../connection/connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
    if($_FILES['avatar']['name'] == "")
    {
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $f_name = $_POST['f_name'];
      $l_name = $_POST['l_name'];
      $m_name = $_POST['m_name'];
      $email = $_POST['email'];  
      $contact = $_POST['contact'];  
      $username = $_POST['username'];  
      $user_type = $_POST['user_type'];
      $query = ("UPDATE tbl_user SET f_name='".$f_name."', l_name='".$l_name."', m_name='".$m_name."', email='".$email."', contact='".$contact."', username='".$username."', user_type='".$user_type."' WHERE user_id = '".$user_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
  }
    else
    {
      include '../../connection/connect.php';
      $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $f_name = $_POST['f_name'];
      $l_name = $_POST['l_name'];
      $m_name = $_POST['m_name'];
      $email = $_POST['email'];  
      $contact = $_POST['contact'];  
      $username = $_POST['username'];  
      $user_type = $_POST['user_type'];
      $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
      $query = ("UPDATE tbl_user SET f_name='".$f_name."', l_name='".$l_name."', m_name='".$m_name."', email='".$email."', contact='".$contact."', username='".$username."', user_type='".$user_type."', avatar='".$avatar."' WHERE user_id = '".$user_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
      error2();
      }
    }
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }  
 ?>  
