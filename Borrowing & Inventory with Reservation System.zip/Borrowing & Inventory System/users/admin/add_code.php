<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
		<script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("../../connection/connect.php");

	$code_name = $_POST['code_name'];
	$description = $_POST['description'];
	$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
	$sql1 = "SELECT * FROM tbl_equipment_code WHERE code_name=?";
			$qry1 =$DbConnect->prepare($sql1);
			$qry1->bind_param("s",$code_name);
			$qry1->execute();
			$qry1->store_result();
			$qry1->fetch();
			if ($qry1->num_rows()<=0)
				{
	if (!empty($code_name))
		{
			$code_name = $_POST['code_name'];
			$description = $_POST['description'];
			$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
			$sql="INSERT INTO tbl_equipment_code (code_name,description,user_id) VALUES (?,?,?)";
			$qry=$DbConnect->prepare($sql);
			$qry->bind_param("sss", $code_name, $description, $user_id);
			if ($qry->execute())
			{
				 succ();

			}
			else
		{
			error1();
		}
		}
		else
		{
			error1();
		}
	}
	else
	{
		err2();
	}
		function succ()
		{
			echo '<script>
			swal({
				title: "Added Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "equipment_code.php";
			});
			</script>';
		}
		function error1()
		{
			echo '<script>
			swal({
				title: "Error!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "equipment_code.php";
			});
			</script>';
		}
		function err2()
		{
			echo '<script>
			swal({
				title: "Code Already Exist",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "equipment_code.php";
			});
			</script>';
		}
	
?>