<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
		<script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("../../connection/connect.php");

	$brand_name = $_POST['brand_name'];
	$description = $_POST['description'];
	$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
	$sql1 = "SELECT * FROM tbl_brand WHERE brand_name=?";
			$qry1 =$DbConnect->prepare($sql1);
			$qry1->bind_param("s",$brand_name);
			$qry1->execute();
			$qry1->store_result();
			$qry1->fetch();
			if ($qry1->num_rows()<=0)
				{
	if (!empty($brand_name))
		{
			$brand_name = $_POST['brand_name'];
			$description = $_POST['description'];
			$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
			$sql="INSERT INTO tbl_brand (brand_name,description,user_id) VALUES (?,?,?)";
			$qry=$DbConnect->prepare($sql);
			$qry->bind_param("sss", $brand_name, $description, $user_id);
			if ($qry->execute())
			{
				 succ();

			}
			else
		{
			error1();
		}
		}
		else
		{
			error1();
		}
	}
	else
	{
		err2();
	}
		function succ()
		{
			echo '<script>
			swal({
				title: "Added Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "Capacity.php ";
			});
			</script>';
		}
		function error1()
		{
			echo '<script>
			swal({
				title: "Error!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "Capacity.php ";
			});
			</script>';
		}
		function err2()
		{
			echo '<script>
			swal({
				title: "Brand Already Exist",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "Capacity.php ";
			});
			</script>';
		}
	
?>