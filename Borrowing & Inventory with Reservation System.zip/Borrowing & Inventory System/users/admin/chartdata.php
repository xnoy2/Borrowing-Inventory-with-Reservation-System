<?php
    require_once "../../connection/connect.php";
 $sql7 = "SELECT tbl_equipment.equipment_id, tbl_equipment.equipment_name, tbl_equipment.code, tbl_equipment.avatar, tbl_equipment.quantity, SUM(tbl_borrowed.req_quantity)as req_quan ,sum(tbl_borrowed.returned_quantity)as ret_quan, sum(tbl_borrowed.damage_quantity)as dam_quan, 
 (tbl_equipment.quantity - SUM(tbl_borrowed.req_quantity)  
  - SUM(tbl_borrowed.damage_quantity) + sum(tbl_borrowed.returned_quantity)) as remaining, (tbl_borrowed.req_quantity - sum(tbl_borrowed.returned_quantity)) as total_borrowed FROM tbl_equipment INNER JOIN tbl_borrowed ON tbl_equipment.equipment_id = 
tbl_borrowed.equipment_id WHERE tbl_borrowed.status = 1 OR tbl_borrowed.status= 2 GROUP BY tbl_equipment.code ASC LIMIT 20";
    $qry7=$DbConnect->prepare($sql7);
    $qry7->bind_result($equipment_id,$equipment_name,$quantity,$code,$avatar,$req_quan,$ret_quan,$dam_quan,$remaining,$total_borrowed);
    $qry7->execute();
    
    $data1;
    $data2;
    $row = 0;

    while ($qry7->fetch())
    {
         $data2[$row] = $req_quan;
            $data1[$row] = $equipment_name;
 
        $row++;
    }
    $color = array("#FF0F00","#FF6600","#FF9E01","#FCD202","#F8FF01","#B0DE09","#04D215","#0D8ECF","#0D52D1","#2A0CD0","#8A0CCF","#CD0D74","#754DEB","#DDDDDD","#999999","#333333");
   
     $charData= '';
    for ($i = 0; $i < $row; $i++)
    {
        $charData .= " {equipment:'".$data1[$i]."', level:".$data2[$i].", color:'". $color[$i]."'}, ";
        
        
    }
    $charData = substr ($charData, 0, -2);
    $charData = "[".$charData."];";
    
    $qry7->close();
    $DbConnect->close();
?>