
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once '../../connection/connect.php';
$supplier_id= isset($_POST['supplier_idz'])? $_POST['supplier_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$supplier_name=$_POST['supplier_name'];
$description=$_POST['description'];
    $sql = "UPDATE tbl_supplier SET supplier_name=?, description=?, user_id=? WHERE supplier_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssss", $supplier_name, $description, $user_id, $supplier_id);
    if ($qry->execute())
    {
     succ();    
    }
    else
    {
        err();
    }
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "supplier.php";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "supplier.php";
            });
            </script>';
        }
     
?>