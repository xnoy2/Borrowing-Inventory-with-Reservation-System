<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
		<script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>
<?php

require_once '../../connection/connect.php';
$brand_id =$_GET['brand_id'];
$sql="DELETE FROM tbl_brand WHERE brand_id=?";
$qry=$DbConnect->prepare($sql);
$qry->bind_param("s",$brand_id);
if($qry->execute()==true)
{
	succ();
	
}
else
{
	err();
}


function succ()
		{
			echo '<script>
			swal({
				title: "Deleted Successfuly",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "capacity.php";
			});
			</script>';
		}
		function err()
		{
			echo '<script>
			swal({
				title: "ERROR!!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "capacity.php";
			});
			</script>';
		}