<?php  
include '../../connection/connect.php';
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_borrowed.borrowed_id,tbl_borrowed.req_quantity,tbl_borrowed.returned_quantity,tbl_borrowed.damage_quantity,tbl_borrowed.date_borrowed,tbl_borrowed.date_returned,tbl_borrowed.remarks,tbl_borrowed.payment,tbl_request.request_id,tbl_request.date_requested,tbl_equipment.equipment_id,tbl_equipment.equipment_name,tbl_equipment.code,tbl_equipment.avatar,tbl_user.user_id, tbl_user.f_name,tbl_user.l_name,tbl_user.user_type FROM tbl_borrowed INNER JOIN tbl_request ON tbl_borrowed.request_id = tbl_request.request_id INNER JOIN tbl_equipment ON tbl_borrowed.equipment_id = tbl_equipment.equipment_id INNER JOIN tbl_user ON tbl_borrowed.user_id = tbl_user.user_id
WHERE tbl_borrowed.status = 2 GROUP BY tbl_borrowed.borrowed_id,tbl_borrowed.req_quantity,tbl_borrowed.returned_quantity,tbl_borrowed.date_borrowed,tbl_borrowed.date_returned,tbl_request.request_id,tbl_request.date_requested,tbl_equipment.equipment_id,tbl_equipment.equipment_name,tbl_equipment.code,tbl_equipment.avatar,tbl_user.user_id, tbl_user.f_name,tbl_user.l_name,tbl_user.user_type  ASC";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($borrowed_id,$date_borrowed,$date_returned,$req_quantity,$returned_quantity,$damage_quantity,$remarks,$payment,$request_id,$date_requested,$equipment_id,$equipment_name,$code,$avatar,$user_id,$f_name,$l_name,$user_type);
$qry->execute();
$result = mysqli_query($connect, $sql);  

while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,f_name,l_name FROM tbl_user WHERE user_id=?";
    ?>
      <tr>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
         <td><?php printf ("%s", $row["equipment_name"]); ?> </td>
         <td><?php printf ("%s", $row["code"]); ?> </td>
         <td><?php printf ("%s", $row["damage_quantity"]); ?> </td>
          <td><?php printf ("%s", $row["remarks"]); ?></td>
         <td><?php printf ("%s", $row["payment"]); ?></td>
          <td>
            <?php 
            if ($row["damage_quantity"] == 0)
            {
              ?>
              <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#view<?php printf ("%s", $row["borrowed_id"]); ?>'><i class='fa fa-edit'></i> 
              </button>
            <?php
          }
          else
            {
              ?>
        
          <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#view<?php printf ("%s", $row["borrowed_id"]); ?>'><i class='fa fa-edit'></i> 
         </button>
         <button type='button' class='btn btn-warning btn-xs' data-toggle='modal' data-target='#pay<?php printf ("%s", $row["borrowed_id"]); ?>'> Pay
         </button>
       <?php  
     }
     ?>
        </td>
              
      </tr>
        
     <div class="modal fade" id="view<?php echo $row['borrowed_id']; ?>">
                        <div class="modal-dialog modal-md">
                          <form action="approved_request.php" method="post" id="form1<?php printf ("%s", $row["request_id"]); ?>"  name="form1">
                          <input type="hidden" name="equipment_idz" value="<?php printf ("%s", $row["equipment_id"]); ?>">
                          <input type="hidden" name="request_idz" value="<?php printf ("%s", $row["request_id"]); ?>">
                          <input type="hidden" name="user_idz" value="<?php printf ("%s", $row["user_id"]); ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title"></h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="col-12 col-sm-12 col-md-12 d-flex align-items-stretch flex-column">
                            <div class="card bg-light d-flex flex-fill">
                              <div class="card-header text-muted border-bottom-0">
                                <h1 class="lead">Borrower Detail</h1>
                              </div>
                              <div class="card-body pt-0">
                                <div class="row">
                                  <div class="col-7">
                                    <h2 class="lead"><b><?php printf ("%s", $row["user_type"]); ?></b></h2>
                                    <p class="text-muted text-sm"><b>Borrower: </b> <?php printf ("%s", $row["f_name"]); ?> <?php printf ("%s", $row["l_name"]); ?> </p>
                                    <ul class="ml-4 mb-0 fa-ul text-muted">
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-balance-scale"></i> </span> Borrowed Qty: <b><?php printf ("%s", $row["req_quantity"]); ?></b></li>
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-balance-scale"></i> </span> Returned Qty: <b><?php printf ("%s", $row["returned_quantity"]); ?></b></li>
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-balance-scale"></i> </span> Damaged Qty: <b><?php printf ("%s", $row["damage_quantity"]); ?></b></li>
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-calendar-alt"></i> </span> Date Requested: <b><?php printf ("%s", $row["date_requested"]); ?></b></li>
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-calendar-alt"></i> </span> Date Borrowed: <b><?php printf ("%s", $row["date_borrowed"]); ?></b></li>
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-calendar-alt"></i> </span> Date Returned: <b><?php printf ("%s", $row["date_returned"]); ?></b></li>

                                    </ul>
                                    <div class="b" style="margin-left:10%; margin-top:48px;">
                                   </div>
                                  </div>
                                  <div class="col-5 text-center">
                                    Equipment: <b><?php printf ("%s", $row["equipment_name"]); ?></b>
                                    <?php
                                          echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'"  alt="user-avatar" class="img-square img-fluid" /> '; 
                                          ?>
                                  </div>
                                </div>
                              </div>
                              
                            </div>
                          </div>
                          </div>
                          
                          </div>
                          </div>
                          <!-- /.modal-content -->
                        </form>
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                       <div class="modal fade" id="pay<?php printf ("%s", $row["borrowed_id"]); ?>">
                              <div class="modal-dialog modal-sm">
                                 <form action="update_payment.php" method="post" id="form1<?php printf ("%s", $row["borrowed_id"]); ?>"  name="form1">
                                  <input type="hidden" name="borrowed_idz" value="<?php printf ("%s", $row["borrowed_id"]); ?>">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title">Payment Form</h5>
                                  </div>
                                  <div class="card card-primary">
                                                    <div class="card-body">
                                                      <div class="form-group">
                                                        <div class="row">
                                                        <div class="col-12">
                                                        <label for="exampleInputEmail1">Payment</label>
                                                        <input type="number" min="0"  class="form-control" placeholder="0" name="payment">
                                                        </div> 
                                                        </div>
                                                      </div>
                                                    </div>
                                  <div class="modal-footer justify-content-between">
                                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                                     <button type="submit"  onclick="form1<?php printf ("%s", $row["borrowed_id"]); ?>.submit();" form="form1" class="btn btn-primary btn-sm" ><i class="fa fa-undo-alt"></i> Return</button>
                                  </div>
                                </div>
                                <!-- /.modal-content -->
                              </div>
                            </form>
                              <!-- /.modal-dialog -->
                            </div>
                            </div>
                 
                            
          
<?php 
  }   
  
?>
