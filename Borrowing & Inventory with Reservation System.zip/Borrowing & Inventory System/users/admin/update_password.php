
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>
</html>
<?php
include '../../connection/connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $npassword = $_POST['npassword'];
      $cpassword = $_POST['cpassword'];
      $npasswordmd5 = md5($npassword);
      $cpasswordmd5 = md5($cpassword);
      if ($npasswordmd5 == $cpasswordmd5)
      {
        $cpasswordmd5 = md5($cpassword);
         $query = ("UPDATE tbl_user SET u_password='".$cpasswordmd5."' WHERE user_id = '".$user_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        echo $user_id;
      }
      }
      else
      {
        error2();
      }
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "The password confirmation does not match",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "user.php ";
      });
      </script>';
    }  
 ?>  
