  <!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
    <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

   
  <?php  
 $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
 if(isset($_POST["avatar"]))  
 {    
  include '../../connection/connect.php';
  $code = $_POST['code'];
  $sql1 = "SELECT * FROM tbl_equipment WHERE code=?";
      $qry1 =$DbConnect->prepare($sql1);
      $qry1->bind_param("s",$code);
      $qry1->execute();
      $qry1->store_result();
      $qry1->fetch();
      if ($qry1->num_rows()<=0)
        {
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_name = $_POST['equipment_name'];
      $quantity = $_POST['quantity'];
      $code = $_POST['code'];
      $brand_id = $_POST['brand_id'];  
      $unit_id = $_POST['unit_id'];  
      $supplier_id = $_POST['supplier_id'];  
      $eq_description = $_POST['eq_description'];
      $date_added = date("Y-m-d");
      $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
            $query = "INSERT INTO tbl_equipment(equipment_name,quantity,code,brand_id,unit_id,supplier_id,user_id,avatar,date_added,eq_description) VALUES ('$equipment_name','$quantity','$code','$brand_id','$unit_id','$supplier_id','$user_id','$avatar','$date_added','$eq_description')";  
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
    }
  else
  {
    err2();
  }
}
    else
  {
  error2();
  }
  function succ()
    {
      echo '<script>
      swal({
        title: "Added Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "equipment.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "equipment.php ";
      });
      </script>';
    }  
      function err2()
    {
      echo '<script>
      swal({
        title: "Code Already Exist",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "equipment.php ";
      });
      </script>';
    }
 ?>  
