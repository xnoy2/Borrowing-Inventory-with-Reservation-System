<?php  
include '../../connection/connect.php';
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_equipment.equipment_id, tbl_equipment.equipment_name, tbl_equipment.code, tbl_equipment.avatar, tbl_equipment.quantity, SUM(tbl_borrowed.req_quantity)as req_quan ,sum(tbl_borrowed.returned_quantity)as ret_quan, sum(tbl_borrowed.damage_quantity)as dam_quan, (tbl_equipment.quantity - SUM(tbl_borrowed.req_quantity)  
  - SUM(tbl_borrowed.damage_quantity) + sum(tbl_borrowed.returned_quantity)) as remaining, (tbl_borrowed.req_quantity - sum(tbl_borrowed.returned_quantity)) as total_borrowed FROM tbl_equipment INNER JOIN tbl_borrowed ON tbl_equipment.equipment_id = 
tbl_borrowed.equipment_id WHERE tbl_borrowed.status = 1 OR tbl_borrowed.status= 2 GROUP BY tbl_equipment.code ASC";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($equipment_id,$equipment_name,$quantity,$code,$avatar,$req_quan,$ret_quan,$dam_quan,$remaining,$total_borrowed);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,f_name,l_name FROM tbl_user WHERE user_id=?";
    ?>
      <tr>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
         <td><?php printf ("%s", $row["equipment_name"]); ?> </td>
         <td><?php printf ("%s", $row["code"]); ?> </td>
         <td><?php printf ("%s", $row["quantity"]); ?> </td>
         <td><?php printf ("%s", $row["req_quan"]); ?> </td>
         <td><?php printf ("%s", $row["ret_quan"]); ?> </td>
         <td><?php printf ("%s", $row["dam_quan"]); ?></td>
         <td><?php printf ("%s", $row["remaining"]); ?> </td>
      </tr>
    
          
<?php 
  }   
  
?>
