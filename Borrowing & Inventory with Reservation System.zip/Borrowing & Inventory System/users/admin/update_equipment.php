
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body> 
</html>
<?php
include '../../connection/connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");
      if ($_FILES['avatar']['name'] !== "")
      {
        date_default_timezone_set("Asia/Manila");
      $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $equipment_name = $_POST['equipment_name'];
      $quantity = $_POST['quantity'];
      $code = $_POST['code'];
      $brand_id = $_POST['brand_id'];  
      $unit_id = $_POST['unit_id'];  
      $supplier_id = $_POST['supplier_id']; 
      $eq_description = $_POST['eq_description'];
       $date_added = date("Y-m-d");
      $avatar = addslashes(file_get_contents($_FILES["avatar"]["tmp_name"]));
      $query = ("UPDATE tbl_equipment SET equipment_name='".$equipment_name."', quantity='".$quantity."', code='".$code."', brand_id='".$brand_id."', unit_id='".$unit_id."', supplier_id='".$supplier_id."', user_id='".$user_id."', avatar='".$avatar."',  date_added='".$date_added."', eq_description='".$eq_description."' WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
      else
      {
      date_default_timezone_set("Asia/Manila");
      $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");
      date_default_timezone_set("Asia/Manila");
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $equipment_name = $_POST['equipment_name'];
      $quantity = $_POST['quantity'];
      $code = $_POST['code'];
      $brand_id = $_POST['brand_id'];  
      $unit_id = $_POST['unit_id'];  
      $supplier_id = $_POST['supplier_id']; 
      $eq_description = $_POST['eq_description'];
       $date_added = date("Y-m-d");
       $query = ("UPDATE tbl_equipment SET equipment_name='".$equipment_name."', quantity='".$quantity."', code='".$code."', brand_id='".$brand_id."', unit_id='".$unit_id."', supplier_id='".$supplier_id."', user_id='".$user_id."',  date_added='".$date_added."', eq_description='".$eq_description."' WHERE equipment_id = '".$equipment_id."'");
      if(mysqli_query($connect, $query))  
      {  
       succ();
      }
      else
      {
        error2();
      }
      }
      
  function succ()
    {
      echo '<script>
      swal({
        title: "Updated Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "equipment.php ";
      });
      </script>';
    }
    function error2()
    {
      echo '<script>
      swal({
        title: "Error!!!..",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "equipment.php ";
      });
      </script>';
    }  
 ?>  
