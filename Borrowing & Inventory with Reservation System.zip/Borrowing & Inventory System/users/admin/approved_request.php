  <!DOCTYPE html>
<html>
  <head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
    <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
  </head>
  

  <body>
    
  </body>

</html>

   
  <?php  
  require_once '../../connection/connect.php';
 $connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
      date_default_timezone_set("Asia/Manila");
      $request_id= isset($_POST['request_idz'])? $_POST['request_idz']:"";
      $user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
      $equipment_id= isset($_POST['equipment_idz'])? $_POST['equipment_idz']:"";
      $req_quantity= isset($_POST['req_quantityz'])? $_POST['req_quantityz']:"";
      $date_borrowed = date("Y-m-d");
      $status = 1;
      $sql="INSERT INTO tbl_borrowed (req_quantity,date_borrowed,request_id,equipment_id,user_id,status) VALUES (?,?,?,?,?,?)";
      $qry=$DbConnect->prepare($sql);
      $qry->bind_param("ssssss",$req_quantity, $date_borrowed,$request_id,$equipment_id,$user_id,$status);
      if ($qry->execute())
      {
    require_once '../../connection/connect.php';
    $request_id= isset($_POST['request_idz'])? $_POST['request_idz']:"";
    $status = 1;
    $sql = "UPDATE tbl_request SET status=? WHERE request_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ss",$status,$request_id);
    if ($qry->execute())
    {
     succ();    
    }
    else
    {
      error1();
    }
  }
    else
    {
        error1();
    }
    function succ()
    {
      echo '<script>
      swal({
        title: "Request Approved Successfully",
        type: "success",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "request.php ";
      });
      </script>';
    }
    function error1()
    {
      echo '<script>
      swal({
        title: "Error!",
        type: "error",
        showCancelButton: false,
        closeOnConfirm: true,
      },
      function ()
      {
        window.location.href = "request.php ";
      });
      </script>';
    }
 ?>  
