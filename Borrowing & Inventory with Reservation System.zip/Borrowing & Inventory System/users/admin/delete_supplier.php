<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
		<script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>
<?php

require_once '../../connection/connect.php';
$supplier_id =$_GET['supplier_id'];
$sql="DELETE FROM tbl_supplier WHERE supplier_id=?";
$qry=$DbConnect->prepare($sql);
$qry->bind_param("s",$supplier_id);
if($qry->execute()==true)
{
	succ();
	
}
else
{
	err();
}


function succ()
		{
			echo '<script>
			swal({
				title: "Deleted Successfuly",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "supplier.php";
			});
			</script>';
		}
		function err()
		{
			echo '<script>
			swal({
				title: "ERROR!!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "supplier.php";
			});
			</script>';
		}