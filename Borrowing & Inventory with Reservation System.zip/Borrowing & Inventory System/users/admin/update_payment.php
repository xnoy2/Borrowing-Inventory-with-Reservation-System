<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
		<script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("../../connection/connect.php");
	$payment = $_POST['payment'];
	$borrowed_id= isset($_POST['borrowed_idz'])? $_POST['borrowed_idz']:"";
	$sql = "UPDATE tbl_borrowed SET  payment=? WHERE borrowed_id=?";
	$qry =$DbConnect->prepare($sql);
	$qry->bind_param("ss",$payment,$borrowed_id);
	if ($qry->execute())
	{
	succ();    
	}
	else
	{
	error1();
	}
			function succ()
		{
			echo '<script>
			swal({
				title: "Paid Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "payment.php ";
			});
			</script>';
		}
		function error1()
		{
			echo '<script>
			swal({
				title: "Error!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "payment.php ";
			});
			</script>';
		}

	
?>