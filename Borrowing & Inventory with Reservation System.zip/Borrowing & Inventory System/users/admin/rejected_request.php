
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once '../../connection/connect.php';
$request_id =$_GET['request_id'];
$status = "2";
    $sql = "UPDATE tbl_request SET status=? WHERE request_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ss",$status,$request_id);
    if ($qry->execute())
    {
     succ();    
    }
    else
    {
        err();
    }
function succ()
        {
            echo '<script>
            swal({
                title: "Request Rejected Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "request.php";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "request.php";
            });
            </script>';
        }
     
?>