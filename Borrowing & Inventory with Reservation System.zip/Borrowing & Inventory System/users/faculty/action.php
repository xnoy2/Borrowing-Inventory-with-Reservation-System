<?php 
include ('../../connection/connect.php');
$equipment_id = mysql_real_escape_string($_POST['equipment_id']);
if($equipment_id!='')
{
$states_result = $DbConnect->query('SELECT tbl_equipment.equipment_id, tbl_equipment.equipment_name, tbl_equipment.code, tbl_equipment.avatar, tbl_equipment.quantity, SUM(tbl_borrowed.req_quantity)as req_quan ,sum(tbl_borrowed.returned_quantity)as ret_quan, sum(tbl_borrowed.damage_quantity)as dam_quan, (tbl_equipment.quantity - SUM(tbl_borrowed.req_quantity)  - SUM(tbl_borrowed.damage_quantity) + sum(tbl_borrowed.returned_quantity)) as remaining, (tbl_borrowed.req_quantity - sum(tbl_borrowed.returned_quantity)) as total_borrowed FROM tbl_equipment INNER JOIN tbl_borrowed ON tbl_equipment.equipment_id = tbl_borrowed.equipment_id WHERE tbl_borrowed.equipment_id = '.$equipment_id.'');
$options = "";
while($row = $states_result->fetch_assoc()) {
$options .= "<option value='".$row['equipment_id']."'>".$row['remaining']."</option>";
}
echo $options;
}?>