<?php  
include '../../connection/connect.php';
date_default_timezone_set("Asia/Manila");
$connect = mysqli_connect("localhost", "root", "root", "borrowingandinventorysystemdb");  
$user_id = $_SESSION['user_id'];
$sql = "SELECT tbl_equipment.equipment_id, tbl_equipment.equipment_name,  tbl_equipment.quantity, tbl_equipment.code,tbl_equipment.avatar,tbl_equipment.date_added, tbl_equipment.eq_description, tbl_brand.brand_id,tbl_brand.brand_name,tbl_unit.unit_id,tbl_unit.unit_name,tbl_supplier.supplier_id,tbl_supplier.supplier_name,tbl_supplier.description, tbl_user.user_id,tbl_user.f_name,tbl_user.l_name
FROM tbl_equipment INNER JOIN tbl_brand ON tbl_equipment.brand_id = tbl_brand.brand_id INNER JOIN tbl_unit ON tbl_equipment.unit_id = tbl_unit.unit_id INNER JOIN tbl_supplier ON tbl_equipment.supplier_id = tbl_supplier.supplier_id INNER JOIN tbl_user ON tbl_equipment.user_id = tbl_user.user_id
GROUP BY tbl_equipment.equipment_id, tbl_equipment.equipment_name, tbl_equipment.quantity, tbl_equipment.code, tbl_brand.brand_id,tbl_brand.brand_name,tbl_unit.unit_id,tbl_unit.unit_name,tbl_supplier.supplier_id,tbl_supplier.supplier_name,tbl_user.user_id,tbl_user.f_name,tbl_user.l_name ASC";
$qry=$DbConnect->prepare($sql);
$qry->bind_result($equipment_id,$equipment_name,$quantity,$code,$avatar,$date_added,$eq_description,$brand_id,$brand_name,$unit_id,$unit_name,$supplier_id,$supplier_name,$description,$user_id,$f_name,$l_name);
$qry->execute();
$result = mysqli_query($connect, $sql);  
while($row = mysqli_fetch_array($result))
  { 
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,f_name,l_name FROM tbl_user WHERE user_id=?";
    ?>
      <tr>
        <?php echo '<td> <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'" height="50" width="50" class="img-square elevation-2" alt="User Image" /> </td>'; ?> 
         <td><?php printf ("%s", $row["equipment_name"]); ?> </td>
         <td><?php printf ("%s", $row["code"]); ?> </td>
         <td><?php printf ("%s", $row["brand_name"]); ?> </td>
          <td><?php printf ("%s", $row["quantity"]); ?> </td>
         <td><?php printf ("%s", $row["unit_name"]); ?> </td>
         <td><?php printf ("%s", $row["date_added"]); ?> </td>
         <td><?php printf ("%s", $row["supplier_name"]); ?> </td>
         <td><?php printf ("%s", $row["eq_description"]); ?> </td>
         <td>
          <button type='button' class='btn btn-xs btn-primary ' data-toggle='modal' data-target='#view<?php printf ("%s", $row["equipment_id"]); ?>'><i class="fa fa-image "></i>  </button>
        </td>
              
      </tr>
                      <div class="modal fade" id="view<?php echo $row['equipment_id']; ?>">
                        <div class="modal-dialog modal-md">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title"></h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="col-12 col-sm-12 col-md-12 d-flex align-items-stretch flex-column">
                            <div class="card bg-light d-flex flex-fill">
                              <div class="card-header text-muted border-bottom-0">
                                Equipment Detail
                              </div>
                              <div class="card-body pt-0">
                                <div class="row">
                                  <div class="col-7">
                                    <h2 class="lead"><b><?php printf ("%s", $row["equipment_name"]); ?></b></h2>
                                    <p class="text-muted text-sm"><b>About: </b> <?php printf ("%s", $row["code"]); ?>/ <?php printf ("%s", $row["brand_name"]); ?> / <?php printf ("%s", $row["unit_name"]); ?> / Qty:  <?php printf ("%s", $row["quantity"]); ?> </p>
                                    <ul class="ml-4 mb-0 fa-ul text-muted">
                                      <li class="small"><span class="fa-li"><i class="fas fa-lg fa-edit"></i> </span> Note: <?php printf ("%s", $row["supplier_name"]); ?></li>
                                    </ul>
                                  </div>
                                  <div class="col-5 text-center">
                                    <?php
                                          echo ' <img src="data:image/jpeg;base64,'.base64_encode($row['avatar'] ).'"  alt="user-avatar" class="img-square img-fluid" /> '; 
                                          ?>
                                  </div>
                                </div>
                              </div>
                              
                            </div>
                          </div>
                          </div>
                          </div>
                          </div>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>

          
<?php 
  }   
  
?>
