
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
        <script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once '../../connection/connect.php';
$request_id= isset($_POST['request_idz'])? $_POST['request_idz']:"";
$req_quantity=$_POST['req_quantity'];
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$equipment_id=$_POST['equipment_id'];
    $sql = "UPDATE tbl_request SET req_quantity=?, equipment_id=?, user_id=? WHERE request_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssss",$req_quantity,$equipment_id,$user_id,$request_id);
    if ($qry->execute())
    {
     succ();    
    }
    else
    {
        err();
    }
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "request.php";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "request.php";
            });
            </script>';
        }
     
?>