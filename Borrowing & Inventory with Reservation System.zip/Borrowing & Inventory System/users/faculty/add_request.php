<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="../../dist/sweetalert.css">
		<script type="text/javascript" src="../../dist/sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php 
	include ("../../connection/connect.php");
	$equipment_id=$_POST['equipment_id'];
	if (!empty($equipment_id))
		{
	date_default_timezone_set("Asia/Manila");
	$date_requested = date("Y-m-d");  
	$req_quantity=$_POST['req_quantity'];
	$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
	$equipment_id=$_POST['equipment_id'];
	$status = "3";
			$sql="INSERT INTO tbl_request (req_quantity,date_requested,status,equipment_id,user_id) VALUES (?,?,?,?,?)";
			$qry=$DbConnect->prepare($sql);
			$qry->bind_param("sssss", $req_quantity,$date_requested,$status,$equipment_id,$user_id);
			if ($qry->execute())
			{
				 succ();

			}
			else
		{
			error1();
		}
		}
		else
		{
			error1();
		}
		function succ()
		{
			echo '<script>
			swal({
				title: "Requested Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "request.php ";
			});
			</script>';
		}
		function error1()
		{
			echo '<script>
			swal({
				title: "Error!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "request.php ";
			});
			</script>';
		}
		function err2()
		{
			echo '<script>
			swal({
				title: "Equipment Already Exist",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "request.php ";
			});
			</script>';
		}
	
?>